Installations Anleitung :

1. Abhängigkeit OpenAL installieren
	- dazu die oalinst.exe ausführen
2. Fertig
	- die SFML-calc.exe kann mit doppelklick aus geführt werden
3. Anmerkung
	- die SFML-calc.exe kann überall augeführt werden, ist benötigt zur vollen funktions fähigkeit allerdings eine
	  default.ttf sowie eine autsch.wav im selben ordner.

Deinstallation :

1. Löschen sie einfach diesen ordner, bzw. seinen inhalt, wenn sie ihn umgezogen haben.

2. Deinstallieren sie OpenAL (wenn sie es nicht mehr brauchen)	
	- Windows Settings -> Apps & Features -> OpenAL -> Unistall